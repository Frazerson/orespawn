# OreSpawn 1.7.10 → 1.20.1: inventory

Generated from OreSpawnMain.java.

## Entities (78)

| Class | Registered name | Lines | Model | Render | Status |
|---|---|---|---|---|---|
| Acid | Acid | 49 | – | – | todo |
| Alien | Alien | 504 | ✓ | ✓ | todo |
| Alosaurus | Alosaurus | 343 | ✓ | ✓ | todo |
| BandP | Criminal | 420 | ✓ | ✓ | todo |
| Baryonyx | Baryonyx | 303 | ✓ | ✓ | todo |
| Basilisk | Basilisk | 544 | ✓ | ✓ | todo |
| Beaver | Beaver | 364 | ✓ | ✓ | todo |
| Bee | Bee | 409 | ✓ | ✓ | todo |
| BerthaHit | BerthaHit | 141 | – | – | todo |
| Boyfriend | Boyfriend | 1082 | – | ✓ | todo |
| Brutalfly | Brutalfly | 522 | ✓ | ✓ | todo |
| Camarasaurus | Camarasaurus | 420 | ✓ | ✓ | todo |
| Cassowary | Cassowary | 184 | ✓ | ✓ | todo |
| CaterKiller | CaterKiller | 753 | ✓ | ✓ | todo |
| CaveFisher | CaveFisher | 335 | ✓ | ✓ | todo |
| Cephadrome | Cephadrome | 1045 | ✓ | ✓ | todo |
| Chipmunk | Chipmunk | 353 | ✓ | ✓ | todo |
| Cockateil | Bird | 309 | ✓ | ✓ | todo |
| Coin | Coin | 188 | ✓ | ✓ | todo |
| Crab | Crab | 565 | ✓ | ✓ | todo |
| Cricket | Cricket | 181 | ✓ | ✓ | todo |
| Cryolophosaurus | Cryolophosaurus | 294 | ✓ | ✓ | todo |
| DeadIrukandji | DeadIrukandji | 49 | – | – | todo |
| Dragon | Dragon | 1525 | ✓ | ✓ | todo |
| Dragonfly | Dragonfly | 317 | ✓ | ✓ | todo |
| EasterBunny | EasterBunny | 658 | ✓ | ✓ | todo |
| Elevator | Hoverboard | 663 | ✓ | ✓ | todo |
| EntityAnt | Ant | 209 | – | – | todo |
| EntityButterfly | Butterfly | 394 | – | – | todo |
| EntityCage | EntityCage | 1080 | – | – | todo |
| EntityLunaMoth | Moth | 212 | – | – | todo |
| EntityMosquito | Mosquito | 179 | – | – | todo |
| EntityThrownRock | EntityThrownRock | 340 | – | – | todo |
| Fairy | Fairy | 414 | ✓ | ✓ | todo |
| Firefly | Firefly | 227 | ✓ | ✓ | todo |
| Flounder | Flounder | 307 | ✓ | ✓ | todo |
| Frog | Frog | 402 | ✓ | ✓ | todo |
| Gazelle | Gazelle | 470 | ✓ | ✓ | todo |
| Ghost | Ghost | 209 | ✓ | ✓ | todo |
| GiantRobot | Jeffery | 450 | ✓ | ✓ | todo |
| Girlfriend | Girlfriend | 1201 | – | ✓ | todo |
| Godzilla | Mobzilla | 1866 | ✓ | ✓ | todo |
| GodzillaHead | MobzillaHead | 185 | – | ✓ | todo |
| Hammerhead | Hammerhead | 382 | ✓ | ✓ | todo |
| Hydrolisc | Hydrolisc | 422 | ✓ | ✓ | todo |
| IceBall | IceBall | 96 | – | – | todo |
| InkSack | InkSack | 99 | – | – | todo |
| Irukandji | Irukandji | 397 | ✓ | ✓ | todo |
| Island | Island | 365 | ✓ | ✓ | todo |
| IslandToo | IslandToo | 470 | – | ✓ | todo |
| KingHead | KingHead | 185 | – | ✓ | todo |
| Kyuubi | Kyuubi | 294 | ✓ | ✓ | todo |
| LaserBall | LaserBall | 232 | – | – | todo |
| Leon | Leonopteryx | 1222 | ✓ | ✓ | todo |
| Lizard | Lizard | 467 | ✓ | ✓ | todo |
| Mantis | Mantis | 490 | ✓ | ✓ | todo |
| Molenoid | Molenoid | 468 | ✓ | ✓ | todo |
| Mothra | Mothra | 570 | – | – | todo |
| Nastysaurus | Nastysaurus | 409 | ✓ | ✓ | todo |
| Ostrich | Ostrich | 669 | ✓ | ✓ | todo |
| Peacock | Peacock | 324 | ✓ | ✓ | todo |
| PitchBlack | Nightmare | 678 | ✓ | ✓ | todo |
| Pointysaurus | Pointysaurus | 373 | ✓ | ✓ | todo |
| PurplePower | PurplePower | 378 | ✓ | ✓ | todo |
| QueenHead | QueenHead | 185 | – | ✓ | todo |
| Rat | Rat | 415 | ✓ | ✓ | todo |
| RockBase | Rock | 299 | ✓ | ✓ | todo |
| Rotator | Rotator | 469 | ✓ | ✓ | todo |
| Scorpion | Scorpion | 365 | ✓ | ✓ | todo |
| Shoes | Shoes | 115 | – | – | todo |
| Skate | Skate | 388 | ✓ | ✓ | todo |
| Stinky | Stinky | 799 | ✓ | ✓ | todo |
| SunspotUrchin | SunspotUrchin | 127 | – | – | todo |
| Termite | Termite | 333 | – | – | todo |
| Triffid | Triffid | 414 | ✓ | ✓ | todo |
| Vortex | Vortex | 466 | ✓ | ✓ | todo |
| WaterBall | WaterBall | 101 | – | – | todo |
| Whale | Whale | 348 | ✓ | ✓ | todo |

## Blocks (211)

| Java var | Registry name | Status |
|---|---|---|
| MySpiderSpawnBlock | OreSpawn_SpiderSpawnBlock | todo |
| MyBatSpawnBlock | OreSpawn_BatSpawnBlock | todo |
| MyCowSpawnBlock | OreSpawn_CowSpawnBlock | todo |
| MyPigSpawnBlock | OreSpawn_PigSpawnBlock | todo |
| MySquidSpawnBlock | OreSpawn_SquidSpawnBlock | todo |
| MyChickenSpawnBlock | OreSpawn_ChickenSpawnBlock | todo |
| MyCreeperSpawnBlock | OreSpawn_CreeperSpawnBlock | todo |
| MySkeletonSpawnBlock | OreSpawn_SkeletonSpawnBlock | todo |
| MyZombieSpawnBlock | OreSpawn_ZombieSpawnBlock | todo |
| MySlimeSpawnBlock | OreSpawn_SlimeSpawnBlock | todo |
| MyGhastSpawnBlock | OreSpawn_GhastSpawnBlock | todo |
| MyZombiePigmanSpawnBlock | OreSpawn_ZombiePigmanSpawnBlock | todo |
| MyEndermanSpawnBlock | OreSpawn_EndermanSpawnBlock | todo |
| MyCaveSpiderSpawnBlock | OreSpawn_CaveSpiderSpawnBlock | todo |
| MySilverfishSpawnBlock | OreSpawn_SilverfishSpawnBlock | todo |
| MyMagmaCubeSpawnBlock | OreSpawn_MagmaCubeSpawnBlock | todo |
| MyWitchSpawnBlock | OreSpawn_WitchSpawnBlock | todo |
| MySheepSpawnBlock | OreSpawn_SheepSpawnBlock | todo |
| MyWolfSpawnBlock | OreSpawn_WolfSpawnBlock | todo |
| MyMooshroomSpawnBlock | OreSpawn_MooshroomSpawnBlock | todo |
| MyWitherBossSpawnBlock | OreSpawn_WitherBossSpawnBlock | todo |
| MyGirlfriendSpawnBlock | OreSpawn_GirlfriendSpawnBlock | todo |
| MyBoyfriendSpawnBlock | OreSpawn_BoyfriendSpawnBlock | todo |
| MyRedCowSpawnBlock | OreSpawn_RedCowSpawnBlock | todo |
| MyCrystalCowSpawnBlock | OreSpawn_CrystalCowSpawnBlock | todo |
| MyVillagerSpawnBlock | OreSpawn_VillagerSpawnBlock | todo |
| MyGoldCowSpawnBlock | OreSpawn_GoldCowSpawnBlock | todo |
| MyEnchantedCowSpawnBlock | OreSpawn_EnchantedCowSpawnBlock | todo |
| MyMOTHRASpawnBlock | OreSpawn_MOTHRASpawnBlock | todo |
| MyAloSpawnBlock | OreSpawn_AloSpawnBlock | todo |
| MyCryoSpawnBlock | OreSpawn_CryoSpawnBlock | todo |
| MyCamaSpawnBlock | OreSpawn_CamaSpawnBlock | todo |
| MyVeloSpawnBlock | OreSpawn_VeloSpawnBlock | todo |
| MyHydroSpawnBlock | OreSpawn_HydroSpawnBlock | todo |
| MyBasilSpawnBlock | OreSpawn_BasilSpawnBlock | todo |
| MyDragonflySpawnBlock | OreSpawn_DragonflySpawnBlock | todo |
| MyEmperorScorpionSpawnBlock | OreSpawn_EmperorScorpionSpawnBlock | todo |
| MyScorpionSpawnBlock | OreSpawn_ScorpionSpawnBlock | todo |
| MyCaveFisherSpawnBlock | OreSpawn_CaveFisherSpawnBlock | todo |
| MySpyroSpawnBlock | OreSpawn_SpyroSpawnBlock | todo |
| MyBaryonyxSpawnBlock | OreSpawn_BaryonyxSpawnBlock | todo |
| MyGammaMetroidSpawnBlock | OreSpawn_GammaMetroidSpawnBlock | todo |
| MyCockateilSpawnBlock | OreSpawn_CockateilSpawnBlock | todo |
| MyKyuubiSpawnBlock | OreSpawn_KyuubiSpawnBlock | todo |
| MyAlienSpawnBlock | OreSpawn_AlienSpawnBlock | todo |
| MyIronGolemSpawnBlock | OreSpawn_IronGolemSpawnBlock | todo |
| MySnowGolemSpawnBlock | OreSpawn_SnowGolemSpawnBlock | todo |
| MyEnderDragonSpawnBlock | OreSpawn_EnderDragonSpawnBlock | todo |
| MyOcelotSpawnBlock | OreSpawn_OcelotSpawnBlock | todo |
| MyWitherSkeletonSpawnBlock | OreSpawn_WitherSkeletonSpawnBlock | todo |
| MyBlazeSpawnBlock | OreSpawn_BlazeSpawnBlock | todo |
| MyAttackSquidSpawnBlock | OreSpawn_AttackSquidSpawnBlock | todo |
| MyWaterDragonSpawnBlock | OreSpawn_WaterDragonSpawnBlock | todo |
| MyCephadromeSpawnBlock | OreSpawn_CephadromeSpawnBlock | todo |
| MyKrakenSpawnBlock | OreSpawn_KrakenSpawnBlock | todo |
| MyLizardSpawnBlock | OreSpawn_LizardSpawnBlock | todo |
| MyDragonSpawnBlock | OreSpawn_DragonSpawnBlock | todo |
| MyBeeSpawnBlock | OreSpawn_BeeSpawnBlock | todo |
| MyHorseSpawnBlock | OreSpawn_HorseSpawnBlock | todo |
| MyTrooperBugSpawnBlock | OreSpawn_TrooperBugSpawnBlock | todo |
| MySpitBugSpawnBlock | OreSpawn_SpitBugSpawnBlock | todo |
| MyStinkBugSpawnBlock | OreSpawn_StinkBugSpawnBlock | todo |
| MyOstrichSpawnBlock | OreSpawn_OstrichSpawnBlock | todo |
| MyGazelleSpawnBlock | OreSpawn_GazelleSpawnBlock | todo |
| MyChipmunkSpawnBlock | OreSpawn_ChipmunkSpawnBlock | todo |
| MyCreepingHorrorSpawnBlock | OreSpawn_CreepingHorrorSpawnBlock | todo |
| MyTerribleTerrorSpawnBlock | OreSpawn_TerribleTerrorSpawnBlock | todo |
| MyCliffRacerSpawnBlock | OreSpawn_CliffRacerSpawnBlock | todo |
| MyTriffidSpawnBlock | OreSpawn_TriffidSpawnBlock | todo |
| MyPitchBlackSpawnBlock | OreSpawn_PitchBlackSpawnBlock | todo |
| MyLurkingTerrorSpawnBlock | OreSpawn_LurkingTerrorSpawnBlock | todo |
| MyGodzillaPartSpawnBlock | OreSpawn_GodzillaPartSpawnBlock | todo |
| MyGodzillaSpawnBlock | OreSpawn_GodzillaSpawnBlock | todo |
| MyTheKingPartSpawnBlock | OreSpawn_TheKingPartSpawnBlock | todo |
| MyTheKingSpawnBlock | OreSpawn_TheKingSpawnBlock | todo |
| MyTheQueenPartSpawnBlock | OreSpawn_TheQueenPartSpawnBlock | todo |
| MyTheQueenSpawnBlock | OreSpawn_TheQueenSpawnBlock | todo |
| MySmallWormSpawnBlock | OreSpawn_SmallWormSpawnBlock | todo |
| MyMediumWormSpawnBlock | OreSpawn_MediumWormSpawnBlock | todo |
| MyLargeWormSpawnBlock | OreSpawn_LargeWormSpawnBlock | todo |
| MyCassowarySpawnBlock | OreSpawn_CassowarySpawnBlock | todo |
| MyCloudSharkSpawnBlock | OreSpawn_CloudSharkSpawnBlock | todo |
| MyGoldFishSpawnBlock | OreSpawn_GoldFishSpawnBlock | todo |
| MyLeafMonsterSpawnBlock | OreSpawn_LeafMonsterSpawnBlock | todo |
| MyTshirtSpawnBlock | OreSpawn_TshirtSpawnBlock | todo |
| MyEnderKnightSpawnBlock | OreSpawn_EnderKnightSpawnBlock | todo |
| MyEnderReaperSpawnBlock | OreSpawn_EnderReaperSpawnBlock | todo |
| MyBeaverSpawnBlock | OreSpawn_BeaverSpawnBlock | todo |
| MyUrchinSpawnBlock | OreSpawn_UrchinSpawnBlock | todo |
| MyFlounderSpawnBlock | OreSpawn_FlounderSpawnBlock | todo |
| MySkateSpawnBlock | OreSpawn_SkateSpawnBlock | todo |
| MyRotatorSpawnBlock | OreSpawn_RotatorSpawnBlock | todo |
| MyPeacockSpawnBlock | OreSpawn_PeacockSpawnBlock | todo |
| MyFairySpawnBlock | OreSpawn_FairySpawnBlock | todo |
| MyDungeonBeastSpawnBlock | OreSpawn_DungeonBeastSpawnBlock | todo |
| MyVortexSpawnBlock | OreSpawn_VortexSpawnBlock | todo |
| MyRatSpawnBlock | OreSpawn_RatSpawnBlock | todo |
| MyWhaleSpawnBlock | OreSpawn_WhaleSpawnBlock | todo |
| MyIrukandjiSpawnBlock | OreSpawn_IrukandjiSpawnBlock | todo |
| MyTRexSpawnBlock | OreSpawn_TRexSpawnBlock | todo |
| MyHerculesSpawnBlock | OreSpawn_HerculesSpawnBlock | todo |
| MyMantisSpawnBlock | OreSpawn_MantisSpawnBlock | todo |
| MyStinkySpawnBlock | OreSpawn_StinkySpawnBlock | todo |
| MyEasterBunnySpawnBlock | OreSpawn_EasterBunnySpawnBlock | todo |
| MyCaterKillerSpawnBlock | OreSpawn_CaterKillerSpawnBlock | todo |
| MyMolenoidSpawnBlock | OreSpawn_MolenoidSpawnBlock | todo |
| MySeaMonsterSpawnBlock | OreSpawn_SeaMonsterSpawnBlock | todo |
| MySeaViperSpawnBlock | OreSpawn_SeaViperSpawnBlock | todo |
| MyLeonSpawnBlock | OreSpawn_LeonSpawnBlock | todo |
| MyHammerheadSpawnBlock | OreSpawn_HammerheadSpawnBlock | todo |
| MyRubberDuckySpawnBlock | OreSpawn_RubberDuckySpawnBlock | todo |
| MyCriminalSpawnBlock | OreSpawn_CriminalSpawnBlock | todo |
| MyBrutalflySpawnBlock | OreSpawn_BrutalflySpawnBlock | todo |
| MyNastysaurusSpawnBlock | OreSpawn_NastysaurusSpawnBlock | todo |
| MyPointysaurusSpawnBlock | OreSpawn_PointysaurusSpawnBlock | todo |
| MyCricketSpawnBlock | OreSpawn_CricketSpawnBlock | todo |
| MyFrogSpawnBlock | OreSpawn_FrogSpawnBlock | todo |
| MySpiderDriverSpawnBlock | OreSpawn_SpiderDriverSpawnBlock | todo |
| MyCrabSpawnBlock | OreSpawn_CrabSpawnBlock | todo |
| MyOreSaltBlock | OreSpawn_OreSaltBlock | todo |
| MyRTPBlock | OreSpawn_RTPBlock | todo |
| MyMoleDirtBlock | OreSpawn_MoleDirtBlock | todo |
| MyOreTitaniumBlock | OreSpawn_OreTitaniumBlock | todo |
| MyOreUraniumBlock | OreSpawn_OreUraniumBlock | todo |
| MyBlockTitaniumBlock | OreSpawn_BlockTitaniumBlock | todo |
| MyBlockMobzillaScaleBlock | OreSpawn_BlockMobzillaScaleBlock | todo |
| MyBlockUraniumBlock | OreSpawn_BlockUraniumBlock | todo |
| MyLavafoamBlock | OreSpawn_LavafoamBlock | todo |
| MyOreRubyBlock | OreSpawn_OreRubyBlock | todo |
| MyBlockRubyBlock | OreSpawn_BlockRubyBlock | todo |
| MyOreAmethystBlock | OreSpawn_OreAmethystBlock | todo |
| MyBlockAmethystBlock | OreSpawn_BlockAmethystBlock | todo |
| MyCrystalPinkBlock | OreSpawn_CrystalPinkBlock | todo |
| MyTigersEyeBlock | OreSpawn_TigersEyeBlock | todo |
| MyPizzaBlock | OreSpawn_PizzaBlock | todo |
| MyDuctTapeBlock | OreSpawn_DuctTapeBlock | todo |
| CrystalStone | OreSpawn_OreCrystalStoneBlock | todo |
| CrystalRat | OreSpawn_OreCrystalRatBlock | todo |
| RedAntTroll | OreSpawn_OreRedAntTrollBlock | todo |
| TermiteTroll | OreSpawn_OreTermiteTrollBlock | todo |
| CrystalFairy | OreSpawn_OreCrystalFairyBlock | todo |
| CrystalCoal | OreSpawn_OreCrystalCoalBlock | todo |
| CrystalGrass | OreSpawn_OreCrystalGrassBlock | todo |
| CrystalCrystal | OreSpawn_OreCrystalCrystalBlock | todo |
| TigersEye | OreSpawn_OreTigersEyeBlock | todo |
| CrystalPlanksBlock | OreSpawn_CrystalPlanksBlock | todo |
| CrystalWorkbenchBlock | OreSpawn_CrystalWorkbenchBlock | todo |
| CrystalFurnaceBlock | OreSpawn_CrystalFurnaceBlock | todo |
| CrystalFurnaceOnBlock | OreSpawn_CrystalFurnaceOnBlock | todo |
| MyStrawberryPlant | OreSpawn_StrawberryPlant | todo |
| MyRadishPlant | OreSpawn_RadishPlant | todo |
| MyRicePlant | OreSpawn_RicePlant | todo |
| MyButterflyPlant | OreSpawn_ButterflyPlant | todo |
| MyMothPlant | OreSpawn_MothPlant | todo |
| MyMosquitoPlant | OreSpawn_MosquitoPlant | todo |
| MyFireflyPlant | OreSpawn_FireflyPlant | todo |
| MyCornPlant1 | OreSpawn_CornPlant1 | todo |
| MyCornPlant2 | OreSpawn_CornPlant2 | todo |
| MyCornPlant3 | OreSpawn_CornPlant3 | todo |
| MyCornPlant4 | OreSpawn_CornPlant4 | todo |
| MyQuinoaPlant1 | OreSpawn_QuinoaPlant1 | todo |
| MyQuinoaPlant2 | OreSpawn_QuinoaPlant2 | todo |
| MyQuinoaPlant3 | OreSpawn_QuinoaPlant3 | todo |
| MyQuinoaPlant4 | OreSpawn_QuinoaPlant4 | todo |
| MyTomatoPlant1 | OreSpawn_TomatoPlant1 | todo |
| MyTomatoPlant2 | OreSpawn_TomatoPlant2 | todo |
| MyTomatoPlant3 | OreSpawn_TomatoPlant3 | todo |
| MyTomatoPlant4 | OreSpawn_TomatoPlant4 | todo |
| MyLettucePlant1 | OreSpawn_LettucePlant1 | todo |
| MyLettucePlant2 | OreSpawn_LettucePlant2 | todo |
| MyLettucePlant3 | OreSpawn_LettucePlant3 | todo |
| MyLettucePlant4 | OreSpawn_LettucePlant4 | todo |
| MyAppleLeaves | OreSpawn_AppleLeaves | todo |
| MyExperienceLeaves | OreSpawn_ExperienceLeaves | todo |
| MyScaryLeaves | OreSpawn_ScaryLeaves | todo |
| MyCherryLeaves | OreSpawn_CherryLeaves | todo |
| MyPeachLeaves | OreSpawn_PeachLeaves | todo |
| MySkyTreeLog | OreSpawn_SkyTreeLog | todo |
| MyDT | OreSpawn_DuplicatorLog | todo |
| MyExperiencePlant | OreSpawn_ExperiencePlant | todo |
| MyCrystalPlant | OreSpawn_CrystalPlant | todo |
| MyCrystalPlant2 | OreSpawn_CrystalPlant2 | todo |
| MyCrystalPlant3 | OreSpawn_CrystalPlant3 | todo |
| MyFlowerPinkBlock | OreSpawn_FlowerPink | todo |
| MyFlowerBlueBlock | OreSpawn_FlowerBlue | todo |
| MyFlowerBlackBlock | OreSpawn_FlowerBlack | todo |
| MyFlowerScaryBlock | OreSpawn_FlowerScary | todo |
| CrystalFlowerRedBlock | OreSpawn_CrystalFlowerRed | todo |
| CrystalFlowerGreenBlock | OreSpawn_CrystalFlowerGreen | todo |
| CrystalFlowerBlueBlock | OreSpawn_CrystalFlowerBlue | todo |
| CrystalFlowerYellowBlock | OreSpawn_CrystalFlowerYellow | todo |
| MyCrystalLeaves | OreSpawn_CrystalLeaves | todo |
| MyCrystalLeaves2 | OreSpawn_CrystalLeaves2 | todo |
| MyCrystalLeaves3 | OreSpawn_CrystalLeaves3 | todo |
| MyCrystalTreeLog | OreSpawn_CrystalTreeLog | todo |
| ExtremeTorch | OreSpawn_ExtremeTorch | todo |
| CrystalTorch | OreSpawn_CrystalTorch | todo |
| KrakenRepellent | OreSpawn_KrakenRepellent | todo |
| CreeperRepellent | OreSpawn_CreeperRepellent | todo |
| MyIslandBlock | OreSpawn_Island | todo |
| MyKingSpawnerBlock | OreSpawn_KingSpawner | todo |
| MyQueenSpawnerBlock | OreSpawn_QueenSpawner | todo |
| MyDungeonSpawnerBlock | OreSpawn_DungeonSpawner | todo |
| MyEnderPearlBlock | OreSpawn_EnderPearlBlock | todo |
| MyEyeOfEnderBlock | OreSpawn_EyeOfEnderBlock | todo |
| MyAntBlock | OreSpawn_AntBlock | todo |
| MyRedAntBlock | OreSpawn_RedAntBlock | todo |
| TermiteBlock | OreSpawn_TermiteBlock | todo |
| CrystalTermiteBlock | OreSpawn_CrystalTermiteBlock | todo |
| MyRainbowAntBlock | OreSpawn_RainbowAntBlock | todo |
| MyUnstableAntBlock | OreSpawn_UnstableAntBlock | todo |

## Items (473)

| Java var | Registry name | Status |
|---|---|---|
| MyPizzaItem | OreSpawn_PizzaItem | todo |
| MyDuctTapeItem | OreSpawn_DuctTapeItem | todo |
| MyIngotUranium | OreSpawn_IngotUranium | todo |
| MyCrystalPinkIngot | OreSpawn_CrystalPinkIngot | todo |
| MyTigersEyeIngot | OreSpawn_TigersEyeIngot | todo |
| MyIngotTitanium | OreSpawn_IngotTitanium | todo |
| MyUltimateSword | OreSpawn_UltimateSword | todo |
| MyNightmareSword | OreSpawn_NightmareSword | todo |
| MyBertha | OreSpawn_Bertha | todo |
| MyHammy | OreSpawn_Hammy | todo |
| MySlice | OreSpawn_Slice | todo |
| MyRoyal | OreSpawn_Royal | todo |
| MyBattleAxe | OreSpawn_BattleAxe | todo |
| MyQueenBattleAxe | OreSpawn_QueenBattleAxe | todo |
| MyChainsaw | OreSpawn_Chainsaw | todo |
| MyUltimatePickaxe | OreSpawn_UltimatePickaxe | todo |
| MyUltimateShovel | OreSpawn_UltimateShovel | todo |
| MyUltimateHoe | OreSpawn_UltimateHoe | todo |
| MyUltimateAxe | OreSpawn_UltimateAxe | todo |
| MyEmeraldSword | OreSpawn_EmeraldSword | todo |
| MyRoseSword | OreSpawn_RoseSword | todo |
| MyExperienceSword | OreSpawn_ExperienceSword | todo |
| MyPoisonSword | OreSpawn_PoisonSword | todo |
| MyRatSword | OreSpawn_RatSword | todo |
| MyFairySword | OreSpawn_FairySword | todo |
| MyMantisClaw | OreSpawn_MantisClaw | todo |
| MyBigHammer | OreSpawn_BigHammer | todo |
| MyEmeraldPickaxe | OreSpawn_EmeraldPickaxe | todo |
| MyEmeraldShovel | OreSpawn_EmeraldShovel | todo |
| MyEmeraldHoe | OreSpawn_EmeraldHoe | todo |
| MyEmeraldAxe | OreSpawn_EmeraldAxe | todo |
| MyCrystalWoodSword | OreSpawn_CrystalWoodSword | todo |
| MyCrystalWoodPickaxe | OreSpawn_CrystalWoodPickaxe | todo |
| MyCrystalWoodShovel | OreSpawn_CrystalWoodShovel | todo |
| MyCrystalWoodHoe | OreSpawn_CrystalWoodHoe | todo |
| MyCrystalWoodAxe | OreSpawn_CrystalWoodAxe | todo |
| MyCrystalPinkSword | OreSpawn_CrystalPinkSword | todo |
| MyCrystalPinkPickaxe | OreSpawn_CrystalPinkPickaxe | todo |
| MyCrystalPinkShovel | OreSpawn_CrystalPinkShovel | todo |
| MyCrystalPinkHoe | OreSpawn_CrystalPinkHoe | todo |
| MyCrystalPinkAxe | OreSpawn_CrystalPinkAxe | todo |
| MyTigersEyeSword | OreSpawn_TigersEyeSword | todo |
| MyTigersEyePickaxe | OreSpawn_TigersEyePickaxe | todo |
| MyTigersEyeShovel | OreSpawn_TigersEyeShovel | todo |
| MyTigersEyeHoe | OreSpawn_TigersEyeHoe | todo |
| MyTigersEyeAxe | OreSpawn_TigersEyeAxe | todo |
| MyCrystalStoneSword | OreSpawn_CrystalStoneSword | todo |
| MyCrystalStonePickaxe | OreSpawn_CrystalStonePickaxe | todo |
| MyCrystalStoneShovel | OreSpawn_CrystalStoneShovel | todo |
| MyCrystalStoneHoe | OreSpawn_CrystalStoneHoe | todo |
| MyCrystalStoneAxe | OreSpawn_CrystalStoneAxe | todo |
| MyRubySword | OreSpawn_RubySword | todo |
| MyRubyPickaxe | OreSpawn_RubyPickaxe | todo |
| MyRubyShovel | OreSpawn_RubyShovel | todo |
| MyRubyHoe | OreSpawn_RubyHoe | todo |
| MyRubyAxe | OreSpawn_RubyAxe | todo |
| MyAmethystSword | OreSpawn_AmethystSword | todo |
| MyAmethystPickaxe | OreSpawn_AmethystPickaxe | todo |
| MyAmethystShovel | OreSpawn_AmethystShovel | todo |
| MyAmethystHoe | OreSpawn_AmethystHoe | todo |
| MyAmethystAxe | OreSpawn_AmethystAxe | todo |
| MyItemShoes | OreSpawn_RedHeels | todo |
| MyItemShoes_1 | OreSpawn_BlackHeels | todo |
| MyItemShoes_2 | OreSpawn_Slippers | todo |
| MyItemShoes_3 | OreSpawn_Boots | todo |
| MyItemGameController | OreSpawn_GameController | todo |
| MyUltimateBow | OreSpawn_UltimateBow | todo |
| MySkateBow | OreSpawn_SkateBow | todo |
| MyUltimateFishingRod | OreSpawn_UltimateFishingRod | todo |
| MyFireFish | OreSpawn_FireFish | todo |
| MySunFish | OreSpawn_SunFish | todo |
| MyLavaEel | OreSpawn_LavaEel | todo |
| MyMothScale | OreSpawn_MothScale | todo |
| MyQueenScale | OreSpawn_QueenScale | todo |
| MyNightmareScale | OreSpawn_NightmareScale | todo |
| MyEmperorScorpionScale | OreSpawn_EmperorScorpionScale | todo |
| MyBasiliskScale | OreSpawn_BasiliskScale | todo |
| MyWaterDragonScale | OreSpawn_WaterDragonScale | todo |
| MyPeacockFeather | OreSpawn_PeacockFeather | todo |
| MyJumpyBugScale | OreSpawn_JumpyBugScale | todo |
| MyKrakenTooth | OreSpawn_KrakenTooth | todo |
| MyGodzillaScale | OreSpawn_GodzillaScale | todo |
| GreenGoo | OreSpawn_GreenGoo | todo |
| SpiderRobotKit | OreSpawn_SpiderRobotKit | todo |
| AntRobotKit | OreSpawn_AntRobotKit | todo |
| ZooKeeper | OreSpawn_ZooKeeper | todo |
| CreeperLauncher | OreSpawn_CreeperLauncher | todo |
| NetherLost | OreSpawn_NetherLost | todo |
| CrystalSticks | OreSpawn_CrystalSticks | todo |
| Sifter | OreSpawn_Sifter | todo |
| MySunspotUrchin | OreSpawn_SunspotUrchin | todo |
| MyWaterBall | OreSpawn_WaterBall | todo |
| MyLaserBall | OreSpawn_LaserBall | todo |
| MyIceBall | OreSpawn_IceBall | todo |
| MySmallRock | OreSpawn_SmallRock | todo |
| MyRock | OreSpawn_Rock | todo |
| MyRedRock | OreSpawn_RedRock | todo |
| MyCrystalRedRock | OreSpawn_CrystalRedRock | todo |
| MyCrystalGreenRock | OreSpawn_CrystalGreenRock | todo |
| MyCrystalBlueRock | OreSpawn_CrystalBlueRock | todo |
| MyCrystalTNTRock | OreSpawn_CrystalTNTRock | todo |
| MyGreenRock | OreSpawn_GreenRock | todo |
| MyBlueRock | OreSpawn_BlueRock | todo |
| MyPurpleRock | OreSpawn_PurpleRock | todo |
| MySpikeyRock | OreSpawn_SpikeyRock | todo |
| MyTNTRock | OreSpawn_TNTRock | todo |
| MyAcid | OreSpawn_Acid | todo |
| MyIrukandji | OreSpawn_Irukandji | todo |
| MyIrukandjiArrow | OreSpawn_IrukandjiArrow | todo |
| MyRayGun | OreSpawn_RayGun | todo |
| MySquidZooka | OreSpawn_SquidZooka | todo |
| MySparkFish | OreSpawn_SparkFish | todo |
| MySalt | OreSpawn_Salt | todo |
| MyPopcorn | OreSpawn_Popcorn | todo |
| MyButteredPopcorn | OreSpawn_ButteredPopcorn | todo |
| MyButteredSaltedPopcorn | OreSpawn_ButteredSaltedPopcorn | todo |
| MyPopcornBag | OreSpawn_PopcornBag | todo |
| MyButter | OreSpawn_Butter | todo |
| MyCornDog | OreSpawn_CornDog | todo |
| MyCheese | OreSpawn_Cheese | todo |
| MyRawCornDog | OreSpawn_RawCornDog | todo |
| MyPeacock | OreSpawn_Peacock | todo |
| MyRawPeacock | OreSpawn_RawPeacock | todo |
| MyRuby | OreSpawn_Ruby | todo |
| MyAmethyst | OreSpawn_Amethyst | todo |
| MyThunderStaff | OreSpawn_ThunderStaff | todo |
| MyWrench | OreSpawn_Wrench | todo |
| MyRawBacon | OreSpawn_RawBacon | todo |
| MyBacon | OreSpawn_Bacon | todo |
| MyRawCrabMeat | OreSpawn_RawCrabMeat | todo |
| MyCrabMeat | OreSpawn_CrabMeat | todo |
| MyButterCandy | OreSpawn_ButterCandy | todo |
| UraniumNugget | OreSpawn_UraniumNugget | todo |
| TitaniumNugget | OreSpawn_TitaniumNugget | todo |
| MyGreenFish | OreSpawn_GreenFish | todo |
| MyBlueFish | OreSpawn_BlueFish | todo |
| MyPinkFish | OreSpawn_PinkFish | todo |
| MyRockFish | OreSpawn_RockFish | todo |
| MyWoodFish | OreSpawn_WoodFish | todo |
| MyGreyFish | OreSpawn_GreyFish | todo |
| MySalad | OreSpawn_Salad | todo |
| MyBLT | OreSpawn_BLT | todo |
| MyCrabbyPatty | OreSpawn_CrabbyPatty | todo |
| BerthaHandle | OreSpawn_BerthaHandle | todo |
| BerthaGuard | OreSpawn_BerthaGuard | todo |
| BerthaBlade | OreSpawn_BerthaBlade | todo |
| MolenoidNose | OreSpawn_MolenoidNose | todo |
| SeaMonsterScale | OreSpawn_SeaMonsterScale | todo |
| WormTooth | OreSpawn_WormTooth | todo |
| TRexTooth | OreSpawn_TRexTooth | todo |
| CaterKillerJaw | OreSpawn_CaterKillerJaw | todo |
| SeaViperTongue | OreSpawn_SeaViperTongue | todo |
| VortexEye | OreSpawn_VortexEye | todo |
| WitherSkeletonEgg | OreSpawn_WitherSkeletonEgg | todo |
| EnderDragonEgg | OreSpawn_EnderDragonEgg | todo |
| SnowGolemEgg | OreSpawn_SnowGolemEgg | todo |
| IronGolemEgg | OreSpawn_IronGolemEgg | todo |
| WitherBossEgg | OreSpawn_WitherBossEgg | todo |
| GirlfriendEgg | OreSpawn_GirlfriendEgg | todo |
| BoyfriendEgg | OreSpawn_BoyfriendEgg | todo |
| TheKingEgg | OreSpawn_TheKingEgg | todo |
| TheQueenEgg | OreSpawn_TheQueenEgg | todo |
| ThePrinceEgg | OreSpawn_ThePrinceEgg | todo |
| RedCowEgg | OreSpawn_RedCowEgg | todo |
| CrystalCowEgg | OreSpawn_CrystalCowEgg | todo |
| GoldCowEgg | OreSpawn_GoldCowEgg | todo |
| EnchantedCowEgg | OreSpawn_EnchantedCowEgg | todo |
| MOTHRAEgg | OreSpawn_MOTHRAEgg | todo |
| AloEgg | OreSpawn_AloEgg | todo |
| CryoEgg | OreSpawn_CryoEgg | todo |
| CamaEgg | OreSpawn_CamaEgg | todo |
| VeloEgg | OreSpawn_VeloEgg | todo |
| HydroEgg | OreSpawn_HydroEgg | todo |
| BasilEgg | OreSpawn_BasilEgg | todo |
| DragonflyEgg | OreSpawn_DragonflyEgg | todo |
| EmperorScorpionEgg | OreSpawn_EmperorScorpionEgg | todo |
| ScorpionEgg | OreSpawn_ScorpionEgg | todo |
| CaveFisherEgg | OreSpawn_CaveFisherEgg | todo |
| SpyroEgg | OreSpawn_SpyroEgg | todo |
| BaryonyxEgg | OreSpawn_BaryonyxEgg | todo |
| GammaMetroidEgg | OreSpawn_GammaMetroidEgg | todo |
| CockateilEgg | OreSpawn_CockateilEgg | todo |
| KyuubiEgg | OreSpawn_KyuubiEgg | todo |
| AlienEgg | OreSpawn_AlienEgg | todo |
| AttackSquidEgg | OreSpawn_AttackSquidEgg | todo |
| WaterDragonEgg | OreSpawn_WaterDragonEgg | todo |
| CephadromeEgg | OreSpawn_CephadromeEgg | todo |
| KrakenEgg | OreSpawn_KrakenEgg | todo |
| LizardEgg | OreSpawn_LizardEgg | todo |
| DragonEgg | OreSpawn_DragonEgg | todo |
| BeeEgg | OreSpawn_BeeEgg | todo |
| TrooperBugEgg | OreSpawn_TrooperBugEgg | todo |
| SpitBugEgg | OreSpawn_SpitBugEgg | todo |
| StinkBugEgg | OreSpawn_StinkBugEgg | todo |
| OstrichEgg | OreSpawn_OstrichEgg | todo |
| GazelleEgg | OreSpawn_GazelleEgg | todo |
| ChipmunkEgg | OreSpawn_ChipmunkEgg | todo |
| CreepingHorrorEgg | OreSpawn_CreepingHorrorEgg | todo |
| TerribleTerrorEgg | OreSpawn_TerribleTerrorEgg | todo |
| CliffRacerEgg | OreSpawn_CliffRacerEgg | todo |
| TriffidEgg | OreSpawn_TriffidEgg | todo |
| PitchBlackEgg | OreSpawn_PitchBlackEgg | todo |
| LurkingTerrorEgg | OreSpawn_LurkingTerrorEgg | todo |
| GodzillaEgg | OreSpawn_GodzillaEgg | todo |
| SmallWormEgg | OreSpawn_SmallWormEgg | todo |
| MediumWormEgg | OreSpawn_MediumWormEgg | todo |
| LargeWormEgg | OreSpawn_LargeWormEgg | todo |
| CassowaryEgg | OreSpawn_CassowaryEgg | todo |
| CloudSharkEgg | OreSpawn_CloudSharkEgg | todo |
| GoldFishEgg | OreSpawn_GoldFishEgg | todo |
| LeafMonsterEgg | OreSpawn_LeafMonsterEgg | todo |
| TshirtEgg | OreSpawn_TshirtEgg | todo |
| EnderKnightEgg | OreSpawn_EnderKnightEgg | todo |
| EnderReaperEgg | OreSpawn_EnderReaperEgg | todo |
| BeaverEgg | OreSpawn_BeaverEgg | todo |
| DungeonBeastEgg | OreSpawn_DungeonBeastEgg | todo |
| RotatorEgg | OreSpawn_RotatorEgg | todo |
| VortexEgg | OreSpawn_VortexEgg | todo |
| PeacockEgg | OreSpawn_PeacockEgg | todo |
| FairyEgg | OreSpawn_FairyEgg | todo |
| RatEgg | OreSpawn_RatEgg | todo |
| FlounderEgg | OreSpawn_FlounderEgg | todo |
| WhaleEgg | OreSpawn_WhaleEgg | todo |
| IrukandjiEgg | OreSpawn_IrukandjiEgg | todo |
| SkateEgg | OreSpawn_SkateEgg | todo |
| UrchinEgg | OreSpawn_UrchinEgg | todo |
| Robot1Egg | OreSpawn_Robot1Egg | todo |
| Robot2Egg | OreSpawn_Robot2Egg | todo |
| Robot3Egg | OreSpawn_Robot3Egg | todo |
| Robot4Egg | OreSpawn_Robot4Egg | todo |
| GhostEgg | OreSpawn_GhostEgg | todo |
| GhostSkellyEgg | OreSpawn_GhostSkellyEgg | todo |
| BrownAntEgg | OreSpawn_BrownAntEgg | todo |
| RedAntEgg | OreSpawn_RedAntEgg | todo |
| RainbowAntEgg | OreSpawn_RainbowAntEgg | todo |
| UnstableAntEgg | OreSpawn_UnstableAntEgg | todo |
| TermiteEgg | OreSpawn_TermiteEgg | todo |
| ButterflyEgg | OreSpawn_ButterflyEgg | todo |
| MothEgg | OreSpawn_MothEgg | todo |
| MosquitoEgg | OreSpawn_MosquitoEgg | todo |
| FireflyEgg | OreSpawn_FireflyEgg | todo |
| TRexEgg | OreSpawn_TRexEgg | todo |
| HerculesEgg | OreSpawn_HerculesEgg | todo |
| MantisEgg | OreSpawn_MantisEgg | todo |
| StinkyEgg | OreSpawn_StinkyEgg | todo |
| Robot5Egg | OreSpawn_Robot5Egg | todo |
| CoinEgg | OreSpawn_CoinEgg | todo |
| EasterBunnyEgg | OreSpawn_EasterBunnyEgg | todo |
| MolenoidEgg | OreSpawn_MolenoidEgg | todo |
| SeaMonsterEgg | OreSpawn_SeaMonsterEgg | todo |
| SeaViperEgg | OreSpawn_SeaViperEgg | todo |
| CaterKillerEgg | OreSpawn_CaterKillerEgg | todo |
| RubberDuckyEgg | OreSpawn_RubberDuckyEgg | todo |
| HammerheadEgg | OreSpawn_HammerheadEgg | todo |
| LeonEgg | OreSpawn_LeonEgg | todo |
| CriminalEgg | OreSpawn_CriminalEgg | todo |
| BrutalflyEgg | OreSpawn_BrutalflyEgg | todo |
| NastysaurusEgg | OreSpawn_NastysaurusEgg | todo |
| PointysaurusEgg | OreSpawn_PointysaurusEgg | todo |
| CricketEgg | OreSpawn_CricketEgg | todo |
| ThePrincessEgg | OreSpawn_ThePrincessEgg | todo |
| FrogEgg | OreSpawn_FrogEgg | todo |
| JefferyEgg | OreSpawn_JefferyEgg | todo |
| AntRobotEgg | OreSpawn_AntRobotEgg | todo |
| SpiderRobotEgg | OreSpawn_SpiderRobotEgg | todo |
| SpiderDriverEgg | OreSpawn_SpiderDriverEgg | todo |
| CrabEgg | OreSpawn_CrabEgg | todo |
| CageEmpty | OreSpawn_CageEmpty | todo |
| CagedSpider | OreSpawn_CagedSpider | todo |
| CagedBat | OreSpawn_CagedBat | todo |
| CagedCow | OreSpawn_CagedCow | todo |
| CagedPig | OreSpawn_CagePig | todo |
| CagedSquid | OreSpawn_CagedSquid | todo |
| CagedChicken | OreSpawn_CagedChicken | todo |
| CagedCreeper | OreSpawn_CagedCreeper | todo |
| CagedSkeleton | OreSpawn_CagedSkeleton | todo |
| CagedZombie | OreSpawn_CagedZombie | todo |
| CagedSlime | OreSpawn_CagedSlime | todo |
| CagedGhast | OreSpawn_CagedGhast | todo |
| CagedZombiePigman | OreSpawn_CagedZombiePigman | todo |
| CagedEnderman | OreSpawn_CagedEnderman | todo |
| CagedCaveSpider | OreSpawn_CagedCaveSpider | todo |
| CagedSilverfish | OreSpawn_CagedSilverfish | todo |
| CagedMagmaCube | OreSpawn_CagedMagmaCube | todo |
| CagedWitch | OreSpawn_CagedWitch | todo |
| CagedSheep | OreSpawn_CagedSheep | todo |
| CagedWolf | OreSpawn_CagedWolf | todo |
| CagedMooshroom | OreSpawn_CagedMooshroom | todo |
| CagedOcelot | OreSpawn_CagedOcelot | todo |
| CagedBlaze | OreSpawn_CagedBlaze | todo |
| CagedGirlfriend | OreSpawn_CagedGirlfriend | todo |
| CagedBoyfriend | OreSpawn_CagedBoyfriend | todo |
| CagedWitherSkeleton | OreSpawn_CagedWitherSkeleton | todo |
| CagedEnderDragon | OreSpawn_CagedEnderDragon | todo |
| CagedSnowGolem | OreSpawn_CagedSnowGolem | todo |
| CagedIronGolem | OreSpawn_CagedIronGolem | todo |
| CagedWitherBoss | OreSpawn_CagedWitherBoss | todo |
| CagedRedCow | OreSpawn_CagedRedCow | todo |
| CagedCrystalCow | OreSpawn_CagedCrystalCow | todo |
| CagedVillager | OreSpawn_CagedVillager | todo |
| CagedGoldCow | OreSpawn_CagedGoldCow | todo |
| CagedEnchantedCow | OreSpawn_CagedEnchantedCow | todo |
| CagedMOTHRA | OreSpawn_CagedMOTHRA | todo |
| CagedAlo | OreSpawn_CagedAlo | todo |
| CagedCryo | OreSpawn_CagedCryo | todo |
| CagedCama | OreSpawn_CagedCama | todo |
| CagedVelo | OreSpawn_CagedVelo | todo |
| CagedHydro | OreSpawn_CagedHydro | todo |
| CagedBasil | OreSpawn_CagedBasil | todo |
| CagedDragonfly | OreSpawn_CagedDragonfly | todo |
| CagedEmperorScorpion | OreSpawn_CagedEmperorScorpion | todo |
| CagedScorpion | OreSpawn_CagedScorpion | todo |
| CagedCaveFisher | OreSpawn_CagedCaveFisher | todo |
| CagedSpyro | OreSpawn_CagedSpyro | todo |
| CagedBaryonyx | OreSpawn_CagedBaryonyx | todo |
| CagedGammaMetroid | OreSpawn_CagedGammaMetroid | todo |
| CagedCockateil | OreSpawn_CagedCockateil | todo |
| CagedKyuubi | OreSpawn_CagedKyuubi | todo |
| CagedAlien | OreSpawn_CagedAlien | todo |
| MyElevator | OreSpawn_Elevator | todo |
| CagedAttackSquid | OreSpawn_CagedAttackSquid | todo |
| CagedWaterDragon | OreSpawn_CagedWaterDragon | todo |
| CagedCephadrome | OreSpawn_CagedCephadrome | todo |
| CagedKraken | OreSpawn_CagedKraken | todo |
| CagedLizard | OreSpawn_CagedLizard | todo |
| CagedDragon | OreSpawn_CagedDragon | todo |
| CagedBee | OreSpawn_CagedBee | todo |
| CagedHorse | OreSpawn_CagedHorse | todo |
| CagedFirefly | OreSpawn_CagedFirefly | todo |
| CagedChipmunk | OreSpawn_CagedChipmunk | todo |
| CagedGazelle | OreSpawn_CagedGazelle | todo |
| CagedOstrich | OreSpawn_CagedOstrich | todo |
| CagedTrooper | OreSpawn_CagedTrooper | todo |
| CagedSpit | OreSpawn_CagedSpit | todo |
| CagedStink | OreSpawn_CagedStink | todo |
| CagedCreepingHorror | OreSpawn_CagedCreepingHorror | todo |
| CagedTerribleTerror | OreSpawn_CagedTerribleTerror | todo |
| CagedCliffRacer | OreSpawn_CagedCliffRacer | todo |
| CagedTriffid | OreSpawn_CagedTriffid | todo |
| CagedPitchBlack | OreSpawn_CagedPitchBlack | todo |
| CagedLurkingTerror | OreSpawn_CagedLurkingTerror | todo |
| CagedSmallWorm | OreSpawn_CagedSmallWorm | todo |
| CagedMediumWorm | OreSpawn_CagedMediumWorm | todo |
| CagedLargeWorm | OreSpawn_CagedLargeWorm | todo |
| CagedCassowary | OreSpawn_CagedCassowary | todo |
| CagedCloudShark | OreSpawn_CagedCloudShark | todo |
| CagedGoldFish | OreSpawn_CagedGoldFish | todo |
| CagedLeafMonster | OreSpawn_CagedLeafMonster | todo |
| CagedEnderKnight | OreSpawn_CagedEnderKnight | todo |
| CagedEnderReaper | OreSpawn_CagedEnderReaper | todo |
| CagedBeaver | OreSpawn_CagedBeaver | todo |
| CagedUrchin | OreSpawn_CagedUrchin | todo |
| CagedFlounder | OreSpawn_CagedFlounder | todo |
| CagedSkate | OreSpawn_CagedSkate | todo |
| CagedRotator | OreSpawn_CagedRotator | todo |
| CagedPeacock | OreSpawn_CagedPeacock | todo |
| CagedFairy | OreSpawn_CagedFairy | todo |
| CagedDungeonBeast | OreSpawn_CagedDungeonBeast | todo |
| CagedVortex | OreSpawn_CagedVortex | todo |
| CagedRat | OreSpawn_CagedRat | todo |
| CagedWhale | OreSpawn_CagedWhale | todo |
| CagedIrukandji | OreSpawn_CagedIrukandji | todo |
| CagedTRex | OreSpawn_CagedTRex | todo |
| CagedHercules | OreSpawn_CagedHercules | todo |
| CagedMantis | OreSpawn_CagedMantis | todo |
| CagedStinky | OreSpawn_CagedStinky | todo |
| CagedEasterBunny | OreSpawn_CagedEasterBunny | todo |
| CagedCaterKiller | OreSpawn_CagedCaterKiller | todo |
| CagedMolenoid | OreSpawn_CagedMolenoid | todo |
| CagedSeaMonster | OreSpawn_CagedSeaMonster | todo |
| CagedSeaViper | OreSpawn_CagedSeaViper | todo |
| CagedLeon | OreSpawn_CagedLeon | todo |
| CagedHammerhead | OreSpawn_CagedHammerhead | todo |
| CagedRubberDucky | OreSpawn_CagedRubberDucky | todo |
| CagedCriminal | OreSpawn_CagedCriminal | todo |
| CagedBrutalfly | OreSpawn_CagedBrutalfly | todo |
| CagedNastysaurus | OreSpawn_CagedNastysaurus | todo |
| CagedPointysaurus | OreSpawn_CagedPointysaurus | todo |
| CagedCricket | OreSpawn_CagedCricket | todo |
| CagedFrog | OreSpawn_CagedFrog | todo |
| CagedSpiderDriver | OreSpawn_CagedSpiderDriver | todo |
| CagedCrab | OreSpawn_CagedCrab | todo |
| MyStrawberry | OreSpawn_Strawberry | todo |
| MyCrystalApple | OreSpawn_CrystalApple | todo |
| MyLove | OreSpawn_Love | todo |
| MyCherry | OreSpawn_Cherry | todo |
| MyPeach | OreSpawn_Peach | todo |
| MyRadish | OreSpawn_Radish | todo |
| MyRice | OreSpawn_Rice | todo |
| MyCornCob | OreSpawn_CornCob | todo |
| MyQuinoa | OreSpawn_Quinoa | todo |
| MyTomato | OreSpawn_Tomato | todo |
| MyLettuce | OreSpawn_Lettuce | todo |
| MyStrawberrySeed | OreSpawn_StrawberrySeed | todo |
| MyButterflySeed | OreSpawn_ButterflySeed | todo |
| MyMothSeed | OreSpawn_MothSeed | todo |
| MyMosquitoSeed | OreSpawn_MosquitoSeed | todo |
| MyFireflySeed | OreSpawn_FireflySeed | todo |
| MagicApple | OreSpawn_MagicApple | todo |
| RandomDungeon | OreSpawn_RandomDungeon | todo |
| MinersDream | OreSpawn_MinersDream | todo |
| UltimateHelmet | OreSpawn_UltimateHelmet | todo |
| UltimateBody | OreSpawn_UltimateBody | todo |
| UltimateLegs | OreSpawn_UltimateLegs | todo |
| UltimateBoots | OreSpawn_UltimateBoots | todo |
| LavaEelHelmet | OreSpawn_LavaEelHelmet | todo |
| LavaEelBody | OreSpawn_LavaEelBody | todo |
| LavaEelLegs | OreSpawn_LavaEelLegs | todo |
| LavaEelBoots | OreSpawn_LavaEelBoots | todo |
| MothScaleHelmet | OreSpawn_MothScaleHelmet | todo |
| MothScaleBody | OreSpawn_MothScaleBody | todo |
| MothScaleLegs | OreSpawn_MothScaleLegs | todo |
| MothScaleBoots | OreSpawn_MothScaleBoots | todo |
| MyAppleSeed | OreSpawn_AppleSeed | todo |
| MyCherrySeed | OreSpawn_CherrySeed | todo |
| MyPeachSeed | OreSpawn_PeachSeed | todo |
| MyStepUp | OreSpawn_StepUp | todo |
| MyStepDown | OreSpawn_StepDown | todo |
| MyStepAccross | OreSpawn_StepAccross | todo |
| EmeraldHelmet | OreSpawn_EmeraldHelmet | todo |
| EmeraldBody | OreSpawn_EmeraldBody | todo |
| EmeraldLegs | OreSpawn_EmeraldLegs | todo |
| EmeraldBoots | OreSpawn_EmeraldBoots | todo |
| MyExperienceCatcher | OreSpawn_ExperienceCatcher | todo |
| MyDeadStinkBug | OreSpawn_DeadStinkBug | todo |
| MyExperienceTreeSeed | OreSpawn_ExperienceTreeSeed | todo |
| ExperienceHelmet | OreSpawn_ExperienceHelmet | todo |
| ExperienceBody | OreSpawn_ExperienceBody | todo |
| ExperienceLegs | OreSpawn_ExperienceLegs | todo |
| ExperienceBoots | OreSpawn_ExperienceBoots | todo |
| RubyHelmet | OreSpawn_RubyHelmet | todo |
| RubyBody | OreSpawn_RubyBody | todo |
| RubyLegs | OreSpawn_RubyLegs | todo |
| RubyBoots | OreSpawn_RubyBoots | todo |
| AmethystHelmet | OreSpawn_AmethystHelmet | todo |
| AmethystBody | OreSpawn_AmethystBody | todo |
| AmethystLegs | OreSpawn_AmethystLegs | todo |
| AmethystBoots | OreSpawn_AmethystBoots | todo |
| ZooCage2 | OreSpawn_ZooCage2 | todo |
| ZooCage4 | OreSpawn_ZooCage4 | todo |
| ZooCage6 | OreSpawn_ZooCage6 | todo |
| ZooCage8 | OreSpawn_ZooCage8 | todo |
| ZooCage10 | OreSpawn_ZooCage10 | todo |
| InstantShelter | OreSpawn_InstantShelter | todo |
| InstantGarden | OreSpawn_InstantGarden | todo |
| CrystalPinkHelmet | OreSpawn_CrystalPinkHelmet | todo |
| CrystalPinkBody | OreSpawn_CrystalPinkBody | todo |
| CrystalPinkLegs | OreSpawn_CrystalPinkLegs | todo |
| CrystalPinkBoots | OreSpawn_CrystalPinkBoots | todo |
| TigersEyeHelmet | OreSpawn_TigersEyeHelmet | todo |
| TigersEyeBody | OreSpawn_TigersEyeBody | todo |
| TigersEyeLegs | OreSpawn_TigersEyeLegs | todo |
| TigersEyeBoots | OreSpawn_TigersEyeBoots | todo |
| PeacockFeatherBoots | OreSpawn_PeacockFeatherBoots | todo |
| PeacockFeatherHelmet | OreSpawn_PeacockFeatherHelmet | todo |
| PeacockFeatherBody | OreSpawn_PeacockFeatherBody | todo |
| PeacockFeatherLegs | OreSpawn_PeacockFeatherLegs | todo |
| MobzillaHelmet | OreSpawn_MobzillaHelmet | todo |
| MobzillaBody | OreSpawn_MobzillaBody | todo |
| MobzillaLegs | OreSpawn_MobzillaLegs | todo |
| MobzillaBoots | OreSpawn_MobzillaBoots | todo |
| RoyalHelmet | OreSpawn_RoyalHelmet | todo |
| RoyalBody | OreSpawn_RoyalBody | todo |
| RoyalLegs | OreSpawn_RoyalLegs | todo |
| RoyalBoots | OreSpawn_RoyalBoots | todo |
| LapisHelmet | OreSpawn_LapisHelmet | todo |
| LapisBody | OreSpawn_LapisBody | todo |
| LapisLegs | OreSpawn_LapisLegs | todo |
| LapisBoots | OreSpawn_LapisBoots | todo |
| QueenHelmet | OreSpawn_QueenHelmet | todo |
| QueenBody | OreSpawn_QueenBody | todo |
| QueenLegs | OreSpawn_QueenLegs | todo |
| QueenBoots | OreSpawn_QueenBoots | todo |
