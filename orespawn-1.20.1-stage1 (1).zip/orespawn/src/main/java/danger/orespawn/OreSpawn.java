package danger.orespawn;

import danger.orespawn.core.ModBlocks;
import danger.orespawn.core.ModCreativeTabs;
import danger.orespawn.core.ModEntities;
import danger.orespawn.core.ModItems;
import danger.orespawn.core.ModSounds;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

/**
 * OreSpawn - port of the 1.7.10 mod to Forge 1.20.1.
 *
 * Package layout:
 *   core  - blocks, items, sounds, creative tab, recipes helpers
 *   mobs  - entities, AI goals, attributes, spawn rules
 *   world - dimensions, structures, ore generation (mostly data-driven)
 *   client- models, renderers, GUIs, key bindings
 */
@Mod(OreSpawn.MODID)
public class OreSpawn {
    public static final String MODID = "orespawn";
    public static final Logger LOGGER = LogUtils.getLogger();

    public OreSpawn() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();

        ModSounds.register(bus);
        ModBlocks.register(bus);
        ModItems.register(bus);
        ModEntities.register(bus);
        ModCreativeTabs.register(bus);
    }
}
