package danger.orespawn.core;

import danger.orespawn.OreSpawn;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

/** Entity types. Mobs are ported in stage 3; see docs/INVENTORY.md. */
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, OreSpawn.MODID);

    public static void register(IEventBus bus) { ENTITIES.register(bus); }
    private ModEntities() {}
}
