package danger.orespawn.core;

import danger.orespawn.OreSpawn;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, OreSpawn.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.orespawn"))
                    .icon(() -> new ItemStack(ModItems.RUBY.get()))
                    .displayItems((params, output) ->
                            // Everything registered in ModItems (incl. BlockItems) goes into the tab.
                            ModItems.ITEMS.getEntries().forEach(e -> output.accept(e.get())))
                    .build());

    public static void register(IEventBus bus) { TABS.register(bus); }
    private ModCreativeTabs() {}
}
